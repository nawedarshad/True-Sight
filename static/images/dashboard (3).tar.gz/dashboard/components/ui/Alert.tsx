import React from 'react';
import { Info } from 'lucide-react';

const Alert = ({ children, className = '', ...props }) => {
    return (
        <div className={`bg-blue-100 border-l-4 border-blue-500 text-blue-700 p-4 ${className}`} role="alert" {...props}>
            <div className="flex items-center">
                <Info className="h-5 w-5 mr-2" />
                {children}
            </div>
        </div>
    );
};

export default Alert;