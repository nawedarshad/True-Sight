'use client';

import React, {useState} from "react";
import Link from "next/link";

const navItems: {
    text: string;
    link: string;
}[] = [
    {text: "Dashboard", link: "/"},
    {text: "Docs", link: "/docs"},
    {text: "API reference", link: "/api-reference"},
]

export const HeaderNav: React.FC = () => {
    const [active, setActive] = useState(0);
    return (
        <nav className={`nav`}>
            {navItems.map((element, index) => (
                <Link
                    key={index}
                    href={element.link}
                    className={active === index ? 'active' : ''}
                    onClick={() => {
                        console.log(`setting ${index} active`)
                        setActive(index)
                    }}
                >
                    {element.text}
                </Link>
            ))}
        </nav>
    )
}