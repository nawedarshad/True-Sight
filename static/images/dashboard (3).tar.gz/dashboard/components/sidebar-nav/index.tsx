'use client';

import React, {useState} from "react";
import {PiGraphDuotone, PiKeyDuotone, PiTerminalWindowDuotone} from "react-icons/pi";
import {IoMdSwitch} from "react-icons/io";
import Link from "next/link";

const sideNavItems: {
    icon: React.ReactNode,
    text: string,
    href: string
} [] = [
    {
        icon: <PiKeyDuotone className={`text-2xl`}/>,
        text: "API keys",
        href: "/dashboard/api-keys"
    },
    {
        icon: <PiTerminalWindowDuotone className={`text-2xl`}/>,
        text: "Playground",
        href: "/dashboard/playground"
    },
    {
        icon: <PiGraphDuotone className={`text-2xl`} />,
        text: "Usage",
        href: "/dashboard/usage"
    },
    {
        icon: <IoMdSwitch className={`text-2xl`} />,
        text: "Fine Tuning",
        href: "/dashboard/fine-tuning"
    }
]

export const SidebarNav: React.FC = () => {
    const [active, setActive] = useState(-1);
    return (
        <nav className={`sidenav flex flex-col items-start w-full`}>
            {sideNavItems.map((element, index) => (
                <Link
                    key={index}
                    href={element.href}
                    className={`${active === index ? 'text-slate-900 font-medium bg-white' : ''} flex w-full px-4 py-2 mx-0 gap-2`}
                    onClick={() => {
                        console.log(`setting ${index} active`)
                        setActive(index)
                    }}
                >
                    {element.icon} <span>{element.text}</span>
                </Link>
            ))}
        </nav>
    );
}