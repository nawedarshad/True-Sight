import React from "react";
import {SidebarNav} from "@/components/sidebar-nav";

export const Sidebar: React.FC = () => {
    return (
        <div className={`w-1/5 h-full bg-slate-200 flex flex-col justify-between items-start`}>
            <SidebarNav />

        </div>
    )
}