import React from "react";
import {PiCaretUpDown, PiGearDuotone, PiUserRectangle, PiUserRectangleDuotone} from "react-icons/pi";
import {TbSlashes} from "react-icons/tb";
import {FaParking} from "react-icons/fa";
import Link from "next/link";
import {HeaderNav} from "@/components/header-nav";

export const Header: React.FC = () => {
    return (
        <div className={`w-full flex justify-between px-4 py-4 bg-slate-300 items-center`}>
            <div className="left-section flex items-center justify-center gap-1">
                <div className={`font-medium flex items-center gap-1`}>
                    <FaParking className={`text-2xl`}/>
                    <span className={`flex items-center`}>
                        <span>Personal</span>
                        <PiCaretUpDown/>
                    </span>
                </div>
                <TbSlashes className={`text-gray-400 text-2xl`}/>
                <div className={`font-medium flex items-center`}>
                    <span>Default Project</span>
                    <PiCaretUpDown/>
                </div>
            </div>
            <div className="header-right flex items-center gap-6">
                <HeaderNav />
                <PiGearDuotone className={`text-2xl`}/>
                <PiUserRectangleDuotone className={`text-3xl`}/>
            </div>
        </div>
    );
}