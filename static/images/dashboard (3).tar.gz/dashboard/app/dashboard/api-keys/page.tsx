import React from 'react';
import { Clock, Edit, Trash2 } from 'lucide-react';
import Button from '@/components/ui/Button';
import Alert from '@/components/ui/Alert';
import { Table, TableHead, TableBody, TableRow, TableCell, TableHeader } from '@/components/ui/Table';

export default function ApiKeys() {
    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">API keys</h1>
                <Button>+ Create new secret key</Button>
            </div>

            <Alert className="mb-6">
                Project API keys have replaced user API keys.
                We recommend using project based API keys for more granular control over your resources.{' '}
                <a href="#" className="text-emerald-500 hover:underline">Learn more</a>
            </Alert>

            <Button variant="outline" className="mb-6">
                View user API keys
            </Button>

            <p className="mb-4">
                As an owner of this project, you can view and manage all API keys in this project.
            </p>

            <p className="mb-6">
                Do not share your API key with others, or expose it in the browser or other client-side code. In order to protect the security of your account, OpenAI may also automatically disable any API key that has leaked publicly.
            </p>

            <p className="mb-6">
                View usage per API key on the <a href="#" className="text-emerald-500 hover:underline">Usage page</a>.
            </p>

            <Table>
                <TableHead>
                    <TableRow>
                        <TableHeader>NAME</TableHeader>
                        <TableHeader>SECRET KEY</TableHeader>
                        <TableHeader>CREATED</TableHeader>
                        <TableHeader>LAST USED <Clock className="inline h-4 w-4 ml-1" /></TableHeader>
                        <TableHeader>CREATED BY</TableHeader>
                        <TableHeader>PERMISSIONS</TableHeader>
                        <TableHeader> </TableHeader>
                    </TableRow>
                </TableHead>
                <TableBody>
                    <TableRow>
                        <TableCell>Nawed Image Detector</TableCell>
                        <TableCell>sk-...w1IC</TableCell>
                        <TableCell>Jul 5, 2024</TableCell>
                        <TableCell>Jul 5, 2024</TableCell>
                        <TableCell>Arif</TableCell>
                        <TableCell>All</TableCell>
                        <TableCell>
                            <div className="flex space-x-2">
                                <Button variant="ghost" className="p-2"><Edit className="h-4 w-4" /></Button>
                                <Button variant="ghost" className="p-2"><Trash2 className="h-4 w-4" /></Button>
                            </div>
                        </TableCell>
                    </TableRow>
                </TableBody>
            </Table>
        </div>
    );
}