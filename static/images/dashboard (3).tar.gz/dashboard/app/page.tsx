import React from 'react';
import { BarChart2, Users, DollarSign, AlertCircle, Plus } from 'lucide-react';
import Button from '@/components/ui/Button';
import Alert from '@/components/ui/Alert';
import { Table, TableHead, TableBody, TableRow, TableCell, TableHeader } from '@/components/ui/Table';

const StatCard = ({ icon, title, value, change }) => (
    <div className="bg-white p-6 rounded-lg shadow">
      <div className="flex items-center">
        {icon}
        <h3 className="ml-3 text-lg font-medium text-gray-900">{title}</h3>
      </div>
      <div className="mt-4">
        <p className="text-2xl font-semibold text-gray-900">{value}</p>
        <p className={`mt-1 text-sm ${change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
          {change >= 0 ? '+' : ''}{change}%
        </p>
      </div>
    </div>
);

export default function Home() {
  return (
      <div className="p-6 bg-gray-100 min-h-screen">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="mt-1 text-sm text-gray-600">Welcome back! Here's an overview of your project.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <StatCard icon={<BarChart2 className="h-6 w-6 text-blue-500" />} title="Total Requests" value="1,234,567" change={12.5} />
          <StatCard icon={<Users className="h-6 w-6 text-green-500" />} title="Active Users" value="45,678" change={-2.3} />
          <StatCard icon={<DollarSign className="h-6 w-6 text-yellow-500" />} title="Revenue" value="$98,765" change={8.7} />
          <StatCard icon={<AlertCircle className="h-6 w-6 text-red-500" />} title="Error Rate" value="0.12%" change={-0.5} />
        </div>

        <Alert className="mb-6">
          Your project is approaching its API usage limit. Consider upgrading your plan to avoid service interruptions.
          <a href="#" className="ml-2 font-medium text-blue-700 hover:text-blue-900">Upgrade now</a>
        </Alert>

        <div className="bg-white rounded-lg shadow mb-6">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Recent Activity</h2>
          </div>
          <Table>
            <TableHead>
              <TableRow>
                <TableHeader>Event</TableHeader>
                <TableHeader>User</TableHeader>
                <TableHeader>Time</TableHeader>
                <TableHeader>Status</TableHeader>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow>
                <TableCell>API Key Created</TableCell>
                <TableCell>john@example.com</TableCell>
                <TableCell>2 hours ago</TableCell>
                <TableCell><span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Success</span></TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Large Batch Processing</TableCell>
                <TableCell>sarah@example.com</TableCell>
                <TableCell>5 hours ago</TableCell>
                <TableCell><span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">In Progress</span></TableCell>
              </TableRow>
              <TableRow>
                <TableCell>User Permissions Updated</TableCell>
                <TableCell>admin@example.com</TableCell>
                <TableCell>1 day ago</TableCell>
                <TableCell><span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Success</span></TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>

        <div className="flex space-x-4">
          <Button className="flex items-center">
            <Plus className="h-5 w-5 mr-2" />
            Create New Project
          </Button>
          <Button variant="outline" className="flex items-center">
            View All Activity
          </Button>
        </div>
      </div>
  );
}